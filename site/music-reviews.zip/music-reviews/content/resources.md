---
title: "Ресурсы"
---  

### Полезные ссылки:  
- [Pitchfork](https://pitchfork.com) — рецензии на музыку.  
- [Bandcamp](https://bandcamp.com) — независимые релизы.  